﻿#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <fstream>
#include <sstream>
using namespace std;

class Vehicle {
private:
    string licensePlate;
    int vehicleId;
    string vehicleType;
public:
    Vehicle(const string& license, int id, const string& type) : licensePlate(license), vehicleId(id), vehicleType(type) {}
    string getLicensePlate() const { return licensePlate; }
    int getVehicleId() const { return vehicleId; }
    string getVehicleType() const { return vehicleType; }
    void setLicensePlate(const string& license) { licensePlate = license; }
    void setVehicleId(int id) { vehicleId = id; }
    void setVehicleType(const string& type) { vehicleType = type; }
};

class ParkingSpot {
private:
    int spotId;
    bool isOccupied;
    string spotType;
public:
    ParkingSpot(int id, const string& type) : spotId(id), isOccupied(false), spotType(type) {}
    int getSpotId() const { return spotId; }
    bool getIsOccupied() const { return isOccupied; }
    string getSpotType() const { return spotType; }
    void setIsOccupied(bool occupied) { isOccupied = occupied; }
    void setSpotType(const string& type) { spotType = type; }
};

class ParkingTicket {
private:
    int ticketId;
    int vehicleId;
    int spotId;
    time_t entryTime;
    time_t exitTime;
public:
    ParkingTicket(int ticket_id, int vehicle_id, int spot_id) : ticketId(ticket_id), vehicleId(vehicle_id), spotId(spot_id), entryTime(time(0)), exitTime(0) {}
    int getTicketId() const { return ticketId; }
    int getVehicleId() const { return vehicleId; }
    int getSpotId() const { return spotId; }
    time_t getEntryTime() const { return entryTime; }
    time_t getExitTime() const { return exitTime; }

    void setExitTime() { exitTime = time(0); }
    double calculateParkingDuration() const { return difftime(exitTime, entryTime) / 3600.0; }
};

class ParkingFeeCalculator {
private:
    float hourlyRate;
    float dailyRate;
public:
    ParkingFeeCalculator(float hourly, float daily) : hourlyRate(hourly), dailyRate(daily) {}
    void setHourlyRate(float rate) { hourlyRate = rate; }
    void setDailyRate(float rate) { dailyRate = rate; }

    float calculateFee(double hours) const {
        if (hours <= 24) {
            return hourlyRate * hours;
        }
        else {
            return dailyRate * (hours / 24);
        }
    }
};

class ParkingLot {
private:
    vector<ParkingSpot> spots;
    vector<Vehicle> vehicles;
    vector<ParkingTicket> tickets;
    ParkingFeeCalculator feeCalculator;
public:
    ParkingLot(int numSpots, float hourlyRate, float dailyRate)
        : feeCalculator(hourlyRate, dailyRate) {
        for (int i = 0; i < numSpots; ++i) {
            spots.emplace_back(i + 1, "regular");
        }
    }

    void addVehicle(const string& license, const string& type) {
        int vehicleId = vehicles.size() + 1;
        vehicles.emplace_back(license, vehicleId, type);
    }

    void assignSpot(int vehicleId) {
        int freeSpots = 0;
        for (const auto& spot : spots) {
            if (!spot.getIsOccupied()) {
                freeSpots++;
            }
        }
        if (freeSpots > 1) { 
            for (auto& spot : spots) {
                if (!spot.getIsOccupied()) {
                    spot.setIsOccupied(true);
                    int ticketId = tickets.size() + 1;
                    tickets.emplace_back(ticketId, vehicleId, spot.getSpotId());
                    break;
                }
            }
        }
        else {
            cout << "Cannot assign spot. At least one spot must remain free.\n";
        }
    }

    void releaseSpot(int vehicleId) {
        for (auto& ticket : tickets) {
            if (ticket.getVehicleId() == vehicleId && ticket.getExitTime() == 0) {
                ticket.setExitTime();
                for (auto& spot : spots) {
                    if (spot.getSpotId() == ticket.getSpotId()) {
                        spot.setIsOccupied(false);
                        break;
                    }
                }
                break;
            }
        }
    }

    void generateReport() const {
        int occupied = 0;
        for (const auto& spot : spots) {
            if (spot.getIsOccupied()) {
                ++occupied;
            }
        }
        cout << "Parking Report: " << occupied << " occupied, " << (spots.size() - occupied) << " available." << endl;
    }

    void generateEarningsReport() const {
        float totalEarnings = 0;
        for (const auto& ticket : tickets) {
            if (ticket.getExitTime() != 0) {
                double duration = ticket.calculateParkingDuration();
                totalEarnings += feeCalculator.calculateFee(duration);
            }
        }
        cout << "Total earnings: $" << totalEarnings << endl;
    }

    void saveData() const {
        ofstream vehiclesFile("vehicles.txt");
        ofstream spotsFile("parkingspots.txt");
        ofstream ticketsFile("parkingtickets.txt");
        for (const auto& vehicle : vehicles) {
            vehiclesFile << vehicle.getLicensePlate() << " "
                << vehicle.getVehicleId() << " "
                << vehicle.getVehicleType() << "\n";
        }
        for (const auto& spot : spots) {
            spotsFile << spot.getSpotId() << " "
                << spot.getIsOccupied() << " "
                << spot.getSpotType() << "\n";
        }
        for (const auto& ticket : tickets) {
            ticketsFile << ticket.getTicketId() << " "
                << ticket.getVehicleId() << " "
                << ticket.getSpotId() << " "
                << ticket.getEntryTime() << " "
                << ticket.getExitTime() << "\n";
        }
    }
    void loadData() {
        ifstream vehiclesFile("vehicles.txt");
        ifstream spotsFile("parkingspots.txt");
        ifstream ticketsFile("parkingtickets.txt");

        vehicles.clear();
        spots.clear();
        tickets.clear();

        string line;
        while (getline(vehiclesFile, line)) {
            istringstream iss(line);
            string license, type;
            int id;
            iss >> license >> id >> type;
            vehicles.emplace_back(license, id, type);
        }
        while (getline(spotsFile, line)) {
            istringstream iss(line);
            int id;
            bool occupied;
            string type;
            iss >> id >> occupied >> type;
            spots.emplace_back(id, type);
            spots.back().setIsOccupied(occupied);
        }
        while (getline(ticketsFile, line)) {
            istringstream iss(line);
            int ticketId, vehicleId, spotId;
            time_t entryTime, exitTime;
            iss >> ticketId >> vehicleId >> spotId >> entryTime >> exitTime;
            tickets.emplace_back(ticketId, vehicleId, spotId);
            if (exitTime != 0) {
                tickets.back().setExitTime();
            }
        }
    }
    const vector<Vehicle>& getVehicles() const {
        return vehicles;
    }
};

int main() {
    ParkingLot lot(100, 2.0f, 20.0f); 

    lot.loadData();

    int choice;
    do {
        cout << "\nParking Management System\n";
        cout << "1. Register Vehicle Entry\n";
        cout << "2. Register Vehicle Exit\n";
        cout << "3. View Current Parking Status\n";
        cout << "4. View Earnings Report\n";
        cout << "5. Save & Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
        case 1: {
            string license, type;
            cout << "Enter license plate: ";
            cin >> license;
            cout << "Enter vehicle type: ";
            cin >> type;
            lot.addVehicle(license, type);
            lot.assignSpot(lot.getVehicles().back().getVehicleId());
            break;
        }
        case 2: {
            int vehicleId;
            cout << "Enter vehicle ID: ";
            cin >> vehicleId;
            lot.releaseSpot(vehicleId);
            break;
        }
        case 3:
            lot.generateReport();
            break;
        case 4:
            lot.generateEarningsReport();
            break;
        case 5:
            lot.saveData();
            break;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 5);
    return 0;
}